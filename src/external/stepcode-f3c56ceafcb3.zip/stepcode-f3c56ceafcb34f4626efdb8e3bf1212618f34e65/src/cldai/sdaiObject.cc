#include <sdai.h>
#include "sc_memmgr.h"

SDAI_sdaiObject::SDAI_sdaiObject() {
}

SDAI_sdaiObject::~SDAI_sdaiObject() {
}
